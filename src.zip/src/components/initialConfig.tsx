// initialConfig.js
const initialConfig = {
  a: 1,
  b: 2,
  f: 6,
};

export default initialConfig;
