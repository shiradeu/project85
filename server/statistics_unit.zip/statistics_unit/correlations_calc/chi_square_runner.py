from .base_metric import BaseMetric
import pandas as pd
import numpy as np
from scipy.stats import chi2_contingency

class ChiSquareRunnerMetric(BaseMetric):
    def is_applicable(self, x: pd.Series, y: pd.Series) -> bool:
        # נבדוק האם שני המשתנים הם קטגוריים או מסוג אובייקט (string)
        try:
            return (
                (pd.api.types.is_categorical_dtype(x) or x.dtype == object) and
                (pd.api.types.is_categorical_dtype(y) or y.dtype == object)
            )
        except:
            return False

    def score(self, x: pd.Series, y: pd.Series) -> float:
        try:
            # בניית טבלת שכיחויות
            contingency = pd.crosstab(x, y)

            # אם הטבלה קטנה מדי – נחזיר NaN
            if contingency.shape[0] < 2 or contingency.shape[1] < 2:
                return np.nan

            # חישוב סטטיסטיקת חי-בריבוע
            chi2, p, dof, expected = chi2_contingency(contingency)

            return chi2  # לחלופין אפשר להחזיר את p אם זה המידע שאתה מחפש
        except Exception as e:
            print(f"[ChiSquareRunnerMetric] Error: {e}")
            return np.nan
    class ChiSquaredMatrix:
        def __init__(self, df):
            self.df = df
            self.cat_cols = df.select_dtypes(include=['object', 'category']).columns
    
        def run(self):
            matrix = pd.DataFrame(index=self.cat_cols, columns=self.cat_cols)
            for col1 in self.cat_cols:
                for col2 in self.cat_cols:
                    if col1 == col2:
                        matrix.loc[col1, col2] = 1.0
                    else:
                        contingency = pd.crosstab(self.df[col1], self.df[col2])
                        try:
                            chi2, _, _, _ = chi2_contingency(contingency)
                            matrix.loc[col1, col2] = chi2
                        except:
                            matrix.loc[col1, col2] = np.nan
            return matrix.astype(float)
    
    def main():
        # Load iris dataset and convert numeric target to category
        data = load_iris()
        df = pd.DataFrame(data.data, columns=data.feature_names)
        df['target'] = pd.Categorical(data.target)
        df['target'] = df['target'].astype(str)
    
        analyzer = ChiSquaredMatrix(df)
        result = analyzer.run()
        print("\n--- Chi-Squared Matrix (Categorical Only) ---")
        print(result.round(3))
    
    if __name__ == "__main__":
        main()