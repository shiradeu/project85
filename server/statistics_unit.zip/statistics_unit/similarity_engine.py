import os
import importlib
import inspect
import pandas as pd
from correlations_calc.base_metric import BaseMetric
from normalize.data_normalizer import DataNormalizer

class SimilarityEngine:
    def __init__(self, df, metrics_package: str, normalizer_config_path: str):
        self.df = df
        self.metrics_package = metrics_package
        self.normalizer_config_path = normalizer_config_path
        self.metric_classes = self._load_metric_classes()
        self.df_normalized = self._normalize_df()

    def _load_metric_classes(self):
        metric_classes = []
        package_path = self.metrics_package.replace('.', '/')
        for file in os.listdir(package_path):
            if file.endswith('.py') and not file.startswith('__') and file != 'base_metric.py':
                module_name = f"{self.metrics_package}.{file[:-3]}"
                module = importlib.import_module(module_name)
                for name, obj in inspect.getmembers(module, inspect.isclass):
                    if issubclass(obj, BaseMetric) and obj is not BaseMetric:
                        print(f"✅ Loaded metric class: {name}")
                        metric_classes.append(obj)
        return metric_classes

    def _normalize_df(self):
        print("🔧 Starting normalization...")
        normalizer = DataNormalizer(self.df, self.normalizer_config_path)
        df_norm = normalizer.runner()
        print("✅ Normalization complete. Columns:", df_norm.columns.tolist())
        return df_norm

    def run(self):
        all_cols = self.df_normalized.columns
        matrix = pd.DataFrame(index=all_cols, columns=all_cols, dtype=float)

        for col1 in all_cols:
            for col2 in all_cols:
                if col1 == col2:
                    matrix.loc[col1, col2] = 1.0
                    continue

                x, y = self.df_normalized[col1], self.df_normalized[col2]
                scores = []

                print(f"\n🔍 Checking pair: {col1} vs {col2}")
                for MetricClass in self.metric_classes:
                    metric = MetricClass()
                    try:
                        applicable = metric.is_applicable(x, y)
                        print(f" - {MetricClass.__name__} is_applicable: {applicable}")
                        if applicable:
                            score = metric.score(x, y)
                            print(f"   → score: {score}")
                            if pd.notna(score) and pd.api.types.is_number(score):
                                scores.append(score)
                            else:
                                print(f"   ⚠️ Skipped non-numeric or NaN score")
                    except Exception as e:
                        print(f"   ❌ Exception in {MetricClass.__name__}: {e}")

                matrix.loc[col1, col2] = sum(scores) / len(scores) if scores else None

        print("\n✅ Matrix construction completed.")
        return matrix.round(3)


def top_variable_pairs(similarity_matrix, top_n=10):
    pairs = []
    for i in similarity_matrix.index:
        for j in similarity_matrix.columns:
            if i != j and pd.notna(similarity_matrix.loc[i, j]):
                pairs.append(((i, j), similarity_matrix.loc[i, j]))
    unique_pairs = {}
    for (var1, var2), score in pairs:
        key = tuple(sorted([var1, var2]))
        if key not in unique_pairs or score > unique_pairs[key]:
            unique_pairs[key] = score
    sorted_pairs = sorted(unique_pairs.items(), key=lambda x: x[1], reverse=True)
    return sorted_pairs[:top_n]


# ================== MAIN ==================

if __name__ == "__main__":
    from sklearn.datasets import load_breast_cancer

    print("📦 Loading dataset...")
    data = load_breast_cancer()
    df = pd.DataFrame(data.data, columns=data.feature_names)
    df["target"] = data.target.astype(str)

    engine = SimilarityEngine(
        df,
        metrics_package="correlations_calc",
        normalizer_config_path="normalize/normalizers_config.json"
    )

    print("\n🚀 Running similarity engine...")
    result = engine.run()

    print("\n=== ✅ Combined Similarity Matrix (Normalized) ===")
    print(result)

    print("\n🔝 Top variable pairs:")
    top_pairs = top_variable_pairs(result, top_n=10)
    for (var1, var2), score in top_pairs:
        print(f"{var1} - {var2}: {score}")
