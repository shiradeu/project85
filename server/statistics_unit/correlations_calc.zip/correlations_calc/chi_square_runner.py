from .base_metric import BaseMetric
import pandas as pd
import numpy as np
from scipy.stats import chi2_contingency

class ChiSquarePValueRunnerMetric(BaseMetric):
    use_normalized = False  # חשוב: על קטגוריים לא מנרמלים

    def is_applicable(self, x: pd.Series, y: pd.Series) -> bool:
        return (
            (x.dtype == 'object' or pd.api.types.is_categorical_dtype(x)) and
            (y.dtype == 'object' or pd.api.types.is_categorical_dtype(y))
        )

    def score(self, x: pd.Series, y: pd.Series) -> float:
        try:
            contingency = pd.crosstab(x, y)
            if contingency.shape[0] < 2 or contingency.shape[1] < 2:
                return np.nan
            _, p_value, _, _ = chi2_contingency(contingency)
            return 1 - p_value  # ככל שיותר תלות, כך יותר קרוב ל-1
        except:
            return np.nan

    class ChiSquaredMatrix:
        def __init__(self, df):
            self.df = df
            self.cat_cols = df.select_dtypes(include=['object', 'category']).columns
    
        def run(self):
            matrix = pd.DataFrame(index=self.cat_cols, columns=self.cat_cols)
            for col1 in self.cat_cols:
                for col2 in self.cat_cols:
                    if col1 == col2:
                        matrix.loc[col1, col2] = 1.0
                    else:
                        contingency = pd.crosstab(self.df[col1], self.df[col2])
                        try:
                            chi2, _, _, _ = chi2_contingency(contingency)
                            matrix.loc[col1, col2] = chi2
                        except:
                            matrix.loc[col1, col2] = np.nan
            return matrix.astype(float)
    
    def main():
        # Load iris dataset and convert numeric target to category
        data = load_iris()
        df = pd.DataFrame(data.data, columns=data.feature_names)
        df['target'] = pd.Categorical(data.target)
        df['target'] = df['target'].astype(str)
    
        analyzer = ChiSquaredMatrix(df)
        result = analyzer.run()
        print("\n--- Chi-Squared Matrix (Categorical Only) ---")
        print(result.round(3))
    
    if __name__ == "__main__":
        main()