from .base_metric import BaseMetric
import pandas as pd
import numpy as np

class CorrelationRunnerMetric(BaseMetric):
    use_normalized = True

    def is_applicable(self, x: pd.Series, y: pd.Series) -> bool:
        return pd.api.types.is_numeric_dtype(x) and pd.api.types.is_numeric_dtype(y)

    def score(self, x: pd.Series, y: pd.Series) -> float:
        try:
            return x.corr(y)
        except:
            return np.nan

    class CorrelationAnalyzer:
            def __init__(self, df):
                self.df = df
                self.numeric_cols = df.select_dtypes(include=['int', 'float']).columns
        
            def run(self):
                matrix = pd.DataFrame(index=self.numeric_cols, columns=self.numeric_cols)
                for col1 in self.numeric_cols:
                    for col2 in self.numeric_cols:
                        if col1 == col2:
                            matrix.loc[col1, col2] = 1.0
                        else:
                            corr, _ = pearsonr(self.df[col1], self.df[col2])
                            matrix.loc[col1, col2] = abs(corr)
                return matrix.astype(float)
        
    def main():
            data = load_breast_cancer()
            df = pd.DataFrame(data.data, columns=data.feature_names)
            
            analyzer = CorrelationAnalyzer(df)
            result = analyzer.run()
            
            print("\n--- Correlation Matrix ---")
            print(result.round(2))
        
    if __name__ == "__main__":
            main()